BELLECARE — SITE E-COMMERCE GRATUIT
====================================

CONTENU
- index.html : site complet, responsive (mobile + ordinateur).
- README.txt : ce guide.

INFORMATIONS DÉJÀ AJOUTÉES
- Marque : BelleCare
- WhatsApp : +212785866064
- Email : yassiryassin592@gmail.com
- Catégories : parfums féminins, soins du corps, soins des pieds.

IMPORTANT AVANT PUBLICATION
1. Ouvrez index.html dans un navigateur pour prévisualiser le site.
2. Les 3 fiches produits sont des exemples : remplacez les noms, descriptions,
   prix et illustrations par vos vrais produits.
3. Le formulaire de commande prépare un message et ouvre WhatsApp.
   Il n'enregistre pas les commandes dans une base de données.
4. Pour recevoir les commandes dans une feuille de calcul sans passer par
   WhatsApp, créez un Google Form gratuit puis ajoutez son lien au site.
5. Vérifiez les prix, stocks, conditions de livraison et informations légales
   avant de publier.

PUBLICATION GRATUITE (OPTION SIMPLE : GITHUB PAGES)
1. Créez un compte sur https://github.com/
2. Créez un nouveau dépôt public, par exemple "bellecare-store".
3. Téléversez index.html à la racine du dépôt.
4. Dans Settings > Pages, choisissez "Deploy from a branch".
5. Choisissez "main" et "/ (root)", puis Save.
6. GitHub affichera l'adresse publique de votre site après publication.

AUTRE OPTION
Vous pouvez aussi publier les fichiers statiques sur un hébergeur gratuit
qui accepte les sites HTML statiques. Les conditions et limites de gratuité
peuvent changer. Un nom de domaine personnalisé n'est pas inclus.

AUCUN MOT DE PASSE OU CODE DE VÉRIFICATION N'EST NÉCESSAIRE POUR CE FICHIER.
Ne partagez jamais votre mot de passe Gmail ni les codes reçus par SMS.
